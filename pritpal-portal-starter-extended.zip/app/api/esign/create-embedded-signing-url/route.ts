import { NextRequest, NextResponse } from "next/server";
import * as docusign from "docusign-esign";
import { supabaseService } from "@/lib/supabaseClient";

/**
 * POST body: { path: string, recipientEmail?: string, recipientName?: string, redirectUrl?: string }
 */
export async function POST(req: NextRequest) {
  try {
    const { path, recipientEmail, recipientName, redirectUrl } = await req.json();
    if (!path) return NextResponse.json({ error: "Missing path" }, { status: 400 });

    const supabase = supabaseService();
    const bucket = "legal-documents";
    const { data: file, error: dlError } = await supabase.storage.from(bucket).download(path);
    if (dlError || !file) return NextResponse.json({ error: "File not found in storage" }, { status: 404 });
    const buffer = Buffer.from(await file.arrayBuffer());
    const base64Doc = buffer.toString("base64");

    // Resolve recipient
    let toEmail = recipientEmail;
    let toName = recipientName;
    if (!toEmail || !toName) {
      const { data: userList } = await supabase.auth.admin.listUsers({ perPage: 1 });
      toEmail = toEmail || userList?.users?.[0]?.email || "recipient@example.com";
      const { data: prof } = await supabase.from('profiles').select('full_name').limit(1).single();
      toName = toName || prof?.full_name || "Client";
    }

    // JWT Token
    const api = new docusign.ApiClient();
    const authServer = process.env.DOCUSIGN_AUTH_SERVER || "account-d.docusign.com";
    api.setOAuthBasePath(authServer);
    const privateKeyBytes = Buffer.from(process.env.DOCUSIGN_PRIVATE_KEY_BASE64 || "", "base64");
    const jwtResult = await api.requestJWTUserToken(
      process.env.DOCUSIGN_INTEGRATOR_KEY!,
      process.env.DOCUSIGN_USER_ID_GUID!,
      ["signature", "impersonation"],
      privateKeyBytes,
      3600
    );
    const accessToken = jwtResult.body.access_token;
    const userInfo = await api.getUserInfo(accessToken);
    const acct = userInfo?.accounts?.[0];
    if (!acct) throw new Error("No DocuSign account");
    const basePath = acct.baseUri + "/restapi";
    const accountId = acct.accountId;
    api.setBasePath(basePath);

    const envelopesApi = new docusign.EnvelopesApi(api);
    const doc = new docusign.Document();
    doc.documentBase64 = base64Doc;
    doc.name = path.split('/').pop() || "Document.pdf";
    doc.fileExtension = "pdf";
    doc.documentId = "1";

    const signer = new docusign.Signer();
    signer.email = toEmail;
    signer.name = toName;
    signer.recipientId = "1";
    signer.clientUserId = "CLIENT-EMBEDDED-1";

    const signHere = new docusign.SignHere();
    signHere.anchorString = "/signHere/"; // optional anchor
    const tabs = new docusign.Tabs();
    tabs.signHereTabs = [signHere];
    signer.tabs = tabs;

    const recipients = new docusign.Recipients();
    recipients.signers = [signer];

    const envelopeDef = new docusign.EnvelopeDefinition();
    envelopeDef.emailSubject = "Please sign this document";
    envelopeDef.documents = [doc];
    envelopeDef.recipients = recipients;
    envelopeDef.status = "sent";

    const results = await envelopesApi.createEnvelope(accountId, { envelopeDefinition: envelopeDef });
    const envelopeId = results.envelopeId;

    const viewReq = new docusign.RecipientViewRequest();
    viewReq.returnUrl = redirectUrl || (process.env.DOCUSIGN_REDIRECT_URI ?? `${process.env.NEXT_PUBLIC_SITE_URL}/portal/documents`);
    viewReq.authenticationMethod = "none";
    viewReq.email = toEmail!;
    viewReq.userName = toName!;
    viewReq.clientUserId = "CLIENT-EMBEDDED-1";

    const viewRes = await envelopesApi.createRecipientView(accountId, envelopeId, { recipientViewRequest: viewReq });
    return NextResponse.json({ url: viewRes.url, envelopeId });
  } catch (err: any) {
    return NextResponse.json({ error: err?.message || "DocuSign error" }, { status: 500 });
  }
}
