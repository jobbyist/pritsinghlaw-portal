import { NextRequest, NextResponse } from "next/server";
import crypto from "crypto";
import { supabaseService } from "@/lib/supabaseClient";

export async function POST(req: NextRequest) {
  const formData = await req.formData();
  const from = String(formData.get('From') || '');
  const body = String(formData.get('Body') || '');

  const _hmac = crypto.createHmac('sha256', process.env.TWILIO_INBOUND_SIGNING_SECRET || 'dev').update(from + body).digest('hex');

  const supabase = supabaseService();
  await supabase.from('messages').insert({ body: `SMS from ${from}: ${body}` });
  return NextResponse.json({ ok: true });
}
