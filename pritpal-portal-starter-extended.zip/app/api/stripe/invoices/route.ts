import Stripe from "stripe";
import { NextResponse } from "next/server";

export async function GET() {
  const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, { apiVersion: "2024-06-20" });
  const customer = process.env.STRIPE_TEST_CUSTOMER_ID;
  if (!customer) return NextResponse.json([]);
  const invoices = await stripe.invoices.list({ customer, limit: 10 });
  return NextResponse.json(invoices.data);
}
