import { NextRequest, NextResponse } from "next/server";
import Stripe from "stripe";
import { supabaseService } from "@/lib/supabaseClient";

export async function POST(req: NextRequest) {
  const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, { apiVersion: "2024-06-20" });
  const supabase = supabaseService();
  // TODO: Get real user context. For demo, pick first user with a stripe_customer_id.
  const { data: prof } = await supabase.from('profiles').select('stripe_customer_id').not('stripe_customer_id', 'is', null).limit(1).single();
  const customerId = prof?.stripe_customer_id || process.env.STRIPE_TEST_CUSTOMER_ID;
  if (!customerId) return NextResponse.json({ error: "No Stripe customer mapped" }, { status: 400 });

  const session = await stripe.billingPortal.sessions.create({
    customer: String(customerId),
    return_url: process.env.STRIPE_CUSTOMER_PORTAL_RETURN_URL || process.env.NEXT_PUBLIC_SITE_URL,
  });
  return NextResponse.json({ url: session.url });
}
