import { NextRequest, NextResponse } from "next/server";
import Stripe from "stripe";
import { supabaseService } from "@/lib/supabaseClient";

export async function POST(req: NextRequest) {
  const sig = req.headers.get('stripe-signature') as string;
  const buf = await req.arrayBuffer();
  const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, { apiVersion: "2024-06-20" });

  let event: Stripe.Event;
  try {
    event = stripe.webhooks.constructEvent(Buffer.from(buf), sig, process.env.STRIPE_WEBHOOK_SECRET!);
  } catch (err: any) {
    return new NextResponse(`Webhook Error: ${err.message}`, { status: 400 });
  }

  const supabase = supabaseService();

  if (event.type === 'invoice.paid' || event.type === 'invoice.payment_succeeded') {
    const invoice = event.data.object as Stripe.Invoice;
    await supabase.from('invoices').upsert({
      id: invoice.id,
      invoice_number: invoice.number || null,
      amount_cents: invoice.amount_paid || 0,
      status: invoice.status,
      description: invoice.lines?.data?.[0]?.description ?? 'Legal Services',
      user_id: null,
      case_id: null
    });
  }
  return NextResponse.json({ received: true });
}
