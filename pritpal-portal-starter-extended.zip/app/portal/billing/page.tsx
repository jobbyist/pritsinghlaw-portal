'use client';
import { useEffect, useState } from "react";

export default function BillingPage() {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [invoices, setInvoices] = useState<any[]>([]);

  useEffect(() => {
    fetch('/api/stripe/invoices').then(r => r.json()).then(setInvoices).catch(console.error);
  }, []);

  async function openPortal() {
    setLoading(true); setError(null);
    const res = await fetch('/api/stripe/create-portal-session', { method: 'POST' });
    setLoading(false);
    if (!res.ok) { setError('Failed to open billing portal'); return; }
    const { url } = await res.json();
    window.location.href = url;
  }

  return (
    <div className="space-y-4">
      <h1>Payments</h1>
      <div className="card">
        <button className="btn" onClick={openPortal} disabled={loading}>{loading ? "Opening..." : "Open Billing Portal"}</button>
        {error && <div className="text-red-400 text-sm mt-2">{error}</div>}
      </div>
      <div className="card">
        <h3 className="mb-2">Billing History</h3>
        <div className="space-y-2">
          {invoices.map((inv:any) => (
            <div key={inv.id} className="rounded-lg border border-white/10 p-3">
              <div className="font-medium">{inv.number}</div>
              <div className="text-white/60 text-sm">{inv.description ?? 'Legal Services'}</div>
              <div className="text-white/80 text-sm">${(inv.amount_paid/100).toFixed(2)} · {inv.status}</div>
            </div>
          ))}
          {invoices.length === 0 && <div className="text-white/60">No invoices yet.</div>}
        </div>
      </div>
    </div>
  );
}
