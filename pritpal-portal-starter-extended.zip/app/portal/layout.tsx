'use client';
import Link from "next/link";
import { useEffect, useState } from "react";
import { supabaseBrowser } from "@/lib/supabaseClient";
import { usePathname } from "next/navigation";
import { cx } from "@/lib/utils";
import { canSeeFirmArea } from "@/lib/roles";

const nav = [
  { href: "/portal", label: "Dashboard" },
  { href: "/portal/cases", label: "Cases" },
  { href: "/portal/documents", label: "Documents" },
  { href: "/portal/messages", label: "Messages" },
  { href: "/portal/billing", label: "Payments" },
  { href: "/portal/appointments", label: "Calendar" },
  { href: "/portal/profile", label: "Profile" },
  { href: "/portal/settings", label: "Settings" },
];

export default function PortalLayout({ children }: { children: React.ReactNode }) {
  const supabase = supabaseBrowser();
  const [userEmail, setUserEmail] = useState<string | null>(null);
  const [role, setRole] = useState<string | null>(null);
  const pathname = usePathname();

  useEffect(() => {
    let mounted = true;
    supabase.auth.getUser().then(async ({ data }) => {
      const email = data.user?.email ?? null;
      if (!email) window.location.href = "/login";
      if (mounted) setUserEmail(email);
      if (data.user?.id) {
        const { data: prof } = await supabase.from('profiles').select('role').eq('user_id', data.user.id).single();
        if (mounted) setRole(prof?.role ?? null);
      }
    });
    return () => { mounted = false; };
  }, []);

  async function signOut() {
    await supabase.auth.signOut();
    window.location.href = "/login";
  }

  return (
    <div className="grid grid-cols-12 gap-4 max-w-7xl mx-auto px-4 pt-6">
      <aside className="col-span-12 md:col-span-3 lg:col-span-2 card">
        <div className="flex items-center gap-3 mb-6">
          <div className="h-10 w-10 rounded-full bg-white/10" />
          <div>
            <div className="font-semibold leading-tight">Law Offices of</div>
            <div className="text-accent font-bold -mt-1">Pritpal Singh</div>
          </div>
        </div>
        <nav className="space-y-1">
          {nav.map(item => (
            <Link key={item.href} href={item.href}
              className={cx("block px-3 py-2 rounded-lg hover:bg-white/10", pathname === item.href ? "bg-white/10" : "")}>
              {item.label}
            </Link>
          ))}
          {canSeeFirmArea(role as any) && (
            <>
              <div className="mt-4 text-white/40 text-xs uppercase tracking-widest">Firm</div>
              <Link href="/firm" className={cx("block px-3 py-2 rounded-lg hover:bg-white/10", pathname.startsWith('/firm') ? "bg-white/10" : "")}>Firm Dashboard</Link>
              <Link href="/firm/cases" className={cx("block px-3 py-2 rounded-lg hover:bg-white/10", pathname === '/firm/cases' ? "bg-white/10" : "")}>All Cases</Link>
            </>
          )}
        </nav>
        <div className="mt-6 text-white/70 text-sm">{userEmail}</div>
        <button className="btn mt-3 w-full" onClick={signOut}>Sign out</button>
      </aside>
      <main className="col-span-12 md:col-span-9 lg:col-span-10">{children}</main>
    </div>
  );
}
