'use client';
import { useEffect } from 'react';

export default function AppointmentsPage() {
  const url = process.env.NEXT_PUBLIC_CALENDLY_URL || process.env.CALENDLY_ORG_URL;

  useEffect(() => {
    if (!document.getElementById('calendly-inline-widget')) {
      const link = document.createElement('link');
      link.href = 'https://assets.calendly.com/assets/external/widget.css'; link.rel='stylesheet';
      document.head.appendChild(link);
      const script = document.createElement('script');
      script.src = 'https://assets.calendly.com/assets/external/widget.js'; script.async = true;
      document.body.appendChild(script);
    }
  }, []);

  return (
    <div className="space-y-4">
      <h1>Calendar</h1>
      <div className="card">
        <div className="calendly-inline-widget" data-url={url || "https://calendly.com/"} style={{minWidth:320, height:700}}/>
      </div>
    </div>
  );
}
