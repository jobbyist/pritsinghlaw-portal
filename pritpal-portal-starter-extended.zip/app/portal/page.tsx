'use client';
import { useEffect, useState } from "react";
import { supabaseBrowser } from "@/lib/supabaseClient";
import Link from "next/link";

type Stat = { label: string, value: number | string, delta?: string };
type Case = { id: string; code: string; title: string; type: string; progress: number; status: string; };

export default function Dashboard() {
  const supabase = supabaseBrowser();
  const [stats, setStats] = useState<Stat[]>([]);
  const [cases, setCases] = useState<Case[]>([]);
  const [invoices, setInvoices] = useState<any[]>([]);
  const [tasks, setTasks] = useState<any[]>([]);

  useEffect(() => {
    (async () => {
      const { data: s } = await supabase.rpc('client_dashboard_stats');
      setStats([
        { label: "Active Cases", value: s?.active_cases ?? 0, delta: s?.active_cases_delta ?? "" },
        { label: "Documents Pending", value: s?.pending_documents ?? 0, delta: s?.pending_documents_delta ?? "" },
        { label: "Messages", value: s?.unread_messages ?? 0, delta: s?.unread_messages_delta ?? "" },
        { label: "Upcoming Deadlines", value: s?.upcoming_deadlines ?? 0, delta: s?.upcoming_deadlines_delta ?? "" },
      ].filter(Boolean) as any);

      const { data: c } = await supabase.from('cases').select('*').order('created_at', { ascending: false }).limit(3);
      setCases(c ?? []);
      const { data: inv } = await supabase.from('invoices').select('*').order('created_at', { ascending: false }).limit(3);
      setInvoices(inv ?? []);
      const { data: t } = await supabase.from('tasks').select('*').order('due_at', { ascending: true }).limit(4);
      setTasks(t ?? []);
    })();
  }, []);

  return (
    <div className="space-y-6">
      <header className="card flex items-center justify-between">
        <div><h1>Dashboard</h1><p className="text-white/70">Welcome back. Here’s the state of your matters.</p></div>
        <div className="text-right text-white/70">{new Date().toLocaleDateString(undefined, { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}</div>
      </header>

      <section className="grid md:grid-cols-4 gap-4">
        {stats.map((s, i) => (
          <div key={i} className="card">
            <div className="text-white/60 text-sm">{s.label}</div>
            <div className="text-3xl font-semibold">{s.value}</div>
            {s.delta && <div className="text-white/60 text-xs mt-1">{s.delta}</div>}
          </div>
        ))}
      </section>

      <section className="grid lg:grid-cols-2 gap-4">
        <div className="card">
          <div className="flex items-center justify-between mb-2">
            <h3>Active Cases</h3>
            <Link href="/portal/cases" className="text-sm">View All</Link>
          </div>
          <div className="space-y-3">
            {cases.map(c => (
              <div key={c.id} className="rounded-lg border border-white/10 p-3">
                <div className="font-medium">{c.title}</div>
                <div className="text-white/60 text-sm">{c.code} · {c.type}</div>
                <div className="w-full bg-white/10 h-2 rounded mt-2"><div className="bg-accent h-2 rounded" style={{width: `${c.progress || 0}%`}}/></div>
                <div className="text-white/70 text-xs mt-1">{c.status}</div>
              </div>
            ))}
            {cases.length === 0 && <div className="text-white/60">No cases yet.</div>}
          </div>
        </div>

        <div className="card">
          <div className="flex items-center justify-between mb-2">
            <h3>Payment History</h3>
            <Link href="/portal/billing" className="text-sm">View All</Link>
          </div>
          <div className="space-y-3">
            {invoices.map(inv => (
              <div key={inv.id} className="rounded-lg border border-white/10 p-3">
                <div className="font-medium">{inv.invoice_number || inv.number}</div>
                <div className="text-white/60 text-sm">{inv.description || 'Legal Services'}</div>
                <div className="text-white/80 text-sm">${((inv.amount_cents || inv.amount_paid || 0)/100).toFixed(2)} · {inv.status}</div>
              </div>
            ))}
            {invoices.length === 0 && <div className="text-white/60">No invoices yet.</div>}
          </div>
        </div>

        <div className="card">
          <div className="flex items-center justify-between mb-2">
            <h3>Upcoming Tasks</h3>
            <Link href="/portal/cases" className="text-sm">View All</Link>
          </div>
          <div className="space-y-3">
            {tasks.map(t => (
              <div key={t.id} className="rounded-lg border border-white/10 p-3">
                <div className="font-medium">{t.title}</div>
                <div className="text-white/60 text-sm">Due: {t.due_at ? new Date(t.due_at).toLocaleDateString() : '—'} · {t.priority}</div>
              </div>
            ))}
            {tasks.length === 0 && <div className="text-white/60">No upcoming tasks.</div>}
          </div>
        </div>
      </section>
    </div>
  );
}
