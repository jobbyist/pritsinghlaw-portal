'use client';
import { useEffect, useState } from "react";
import { supabaseBrowser } from "@/lib/supabaseClient";

export default function ProfilePage() {
  const supabase = supabaseBrowser();
  const [profile, setProfile] = useState<any>({ full_name: '', phone: '', role: 'client' });

  useEffect(() => {
    supabase.from('profiles').select('*').single().then(({ data }) => setProfile(data ?? {}));
  }, []);

  async function save() {
    await supabase.from('profiles').upsert(profile);
    alert('Saved');
  }

  return (
    <div className="space-y-4">
      <h1>Profile</h1>
      <div className="card space-y-3">
        <div><div className="label">Full name</div>
          <input className="input" value={profile.full_name || ''} onChange={e=>setProfile({...profile, full_name: e.target.value})}/>
        </div>
        <div><div className="label">Phone</div>
          <input className="input" value={profile.phone || ''} onChange={e=>setProfile({...profile, phone: e.target.value})}/>
        </div>
        <div><div className="label">Role</div>
          <input className="input" value={profile.role || ''} onChange={e=>setProfile({...profile, role: e.target.value})} readOnly/>
          <div className="text-white/50 text-xs mt-1">Role is managed by the firm admin.</div>
        </div>
        <button className="btn" onClick={save}>Save</button>
      </div>
    </div>
  );
}
