'use client';
import { useEffect, useState } from "react";
import { supabaseBrowser } from "@/lib/supabaseClient";

export default function CasesPage() {
  const supabase = supabaseBrowser();
  const [rows, setRows] = useState<any[]>([]);

  useEffect(() => {
    supabase.from('cases').select('*').order('created_at', { ascending: false }).then(({ data }) => setRows(data ?? []));
  }, []);

  return (
    <div className="space-y-4">
      <h1>Cases</h1>
      <div className="card">
        <table className="w-full text-sm">
          <thead className="text-white/60">
            <tr><th className="text-left py-2">Code</th><th className="text-left">Title</th><th>Type</th><th>Status</th><th>Progress</th></tr>
          </thead>
          <tbody>
            {rows.map(r => (
              <tr key={r.id} className="border-t border-white/10">
                <td className="py-2">{r.code}</td>
                <td>{r.title}</td>
                <td className="text-center">{r.type}</td>
                <td className="text-center">{r.status}</td>
                <td className="text-center">{r.progress}%</td>
              </tr>
            ))}
            {rows.length === 0 && <tr><td className="py-3 text-white/60" colSpan={5}>No cases yet.</td></tr>}
          </tbody>
        </table>
      </div>
    </div>
  );
}
