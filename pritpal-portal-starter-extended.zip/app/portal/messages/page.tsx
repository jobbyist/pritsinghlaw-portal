'use client';
import { useEffect, useRef, useState } from "react";
import { supabaseBrowser } from "@/lib/supabaseClient";

export default function MessagesPage() {
  const supabase = supabaseBrowser();
  const [rows, setRows] = useState<any[]>([]);
  const [text, setText] = useState('');
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    (async () => {
      const { data } = await supabase.from('messages').select('*').order('created_at', { ascending: true }).limit(200);
      setRows(data ?? []);
      supabase.channel('realtime:messages')
        .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'messages' }, (payload) => {
          setRows(prev => [...prev, payload.new as any]);
          setTimeout(()=>bottomRef.current?.scrollIntoView({behavior:'smooth'}), 50);
        })
        .subscribe();
    })();
  }, []);

  async function send() {
    if (!text.trim()) return;
    await supabase.from('messages').insert({ body: text });
    setText('');
  }

  return (
    <div className="space-y-4">
      <h1>Messages</h1>
      <div className="card h-[60vh] flex flex-col">
        <div className="flex-1 overflow-auto space-y-2">
          {rows.map(r => (
            <div key={r.id} className="rounded-lg bg-white/10 px-3 py-2">
              <div className="text-white/60 text-xs">{new Date(r.created_at).toLocaleString()}</div>
              <div>{r.body}</div>
            </div>
          ))}
          <div ref={bottomRef} />
        </div>
        <div className="flex gap-2 mt-3">
          <input className="input" placeholder="Type a message..." value={text} onChange={e=>setText(e.target.value)} onKeyDown={e=> e.key==='Enter' && send()}/>
          <button onClick={send} className="btn">Send</button>
        </div>
      </div>
      <div className="card-muted text-sm text-white/70">
        SMS bridge via Twilio webhook at <code>/api/twilio/inbound</code>.
      </div>
    </div>
  );
}
