'use client';
import { useEffect, useState } from "react";
import { supabaseBrowser } from "@/lib/supabaseClient";

export default function DocumentsPage() {
  const supabase = supabaseBrowser();
  const [docs, setDocs] = useState<any[]>([]);
  const [file, setFile] = useState<File | null>(null);
  const bucket = "legal-documents";

  async function load() {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return;
    const { data } = await supabase.storage.from(bucket).list(user.id, { limit: 50 });
    setDocs((data ?? []).filter(d => d.name !== ".emptyFolderPlaceholder"));
  }

  useEffect(() => { load(); }, []);

  async function upload() {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user || !file) return;
    const path = `${user.id}/${Date.now()}-${file.name}`;
    const { error } = await supabase.storage.from(bucket).upload(path, file);
    if (!error) load();
  }

  return (
    <div className="space-y-4">
      <h1>Documents</h1>
      <div className="card">
        <div className="flex gap-2 items-center">
          <input className="input" type="file" onChange={e=> setFile(e.target.files?.[0] ?? null)} />
          <button className="btn" onClick={upload}>Upload</button>
        </div>
      </div>

      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
        {docs.map(d => (<DocCard key={d.name} doc={d} bucket={bucket} />))}
        {docs.length === 0 && <div className="text-white/60">No documents yet.</div>}
      </div>
    </div>
  );
}

function DocCard({ doc, bucket }: { doc: any, bucket: string }) {
  const supabase = supabaseBrowser();
  const [fullPath, setFullPath] = useState<string>('');

  useEffect(() => {
    (async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (user) setFullPath(`${user.id}/${doc.name}`);
    })();
  }, []);

  async function download() {
    const { data: { publicUrl } } = await supabase.storage.from(bucket).getPublicUrl(fullPath);
    window.open(publicUrl, '_blank');
  }

  async function sign() {
    const res = await fetch('/api/esign/create-embedded-signing-url', {
      method: 'POST',
      headers: {'Content-Type':'application/json'},
      body: JSON.stringify({ path: fullPath })
    });
    const json = await res.json();
    if (json?.url) window.open(json.url, '_blank', 'noopener');
    else alert(json?.error || 'Failed to create signing URL');
  }

  return (
    <div className="card">
      <div className="font-medium">{doc.name}</div>
      <div className="text-white/60 text-sm">{Math.round(((doc.metadata?.size ?? 0) / 1024))} KB</div>
      <div className="flex gap-2 mt-3">
        <button className="btn-ghost" onClick={sign}>E‑Sign</button>
        <button className="btn-ghost" onClick={download}>Download</button>
      </div>
    </div>
  );
}
