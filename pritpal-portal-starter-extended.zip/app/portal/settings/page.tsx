export default function SettingsPage() {
  return (
    <div className="space-y-4">
      <h1>Settings</h1>
      <div className="card">
        <p className="text-white/70">More settings coming soon: notifications, 2FA, connected accounts.</p>
      </div>
    </div>
  );
}
